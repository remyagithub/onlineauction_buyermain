package com.eauction.buyer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuyerBidApplicationTests {

	@Test
	void contextLoads() {
	}

}
